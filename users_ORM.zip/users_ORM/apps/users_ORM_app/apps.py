from __future__ import unicode_literals

from django.apps import AppConfig


class UsersOrmAppConfig(AppConfig):
    name = 'users_ORM_app'
